﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MMTProductAPI.Models
{
    public class Category
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]  //For automatically generation of Id by database itself
        public int Id { get; set; }

        //Data Annotation
        [Required]
        [MaxLength(100, ErrorMessage = "Name cannot be more than 50 characters")]
        public string Name { get; set; }

        //Navigation
        public virtual ICollection<ProductCategory> ProductCategories { get; set; }
    }
}
