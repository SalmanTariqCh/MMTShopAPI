﻿
INSERT INTO Categories
VALUES('HOME')

INSERT INTO Categories
VALUES('Garden')

INSERT INTO Categories
VALUES('Electronics')

INSERT INTO Categories
VALUES('Fitness')

INSERT INTO Categories
VALUES('Toys')



INSERT INTO Products (SKU, Description, Price, Name)
VALUES ('111-111-111', 'Furniture', 123.99, 'Table')

INSERT INTO Products (SKU, Description, Price, Name)
VALUES ('111-222-111', 'Furniture', 155.99, 'Bed')

INSERT INTO Products (SKU, Description, Price, Name)
VALUES ('222-222-222', 'Accessories', 209.99, 'Artifical Grass')


INSERT INTO Products (SKU, Description, Price, Name)
VALUES ('333-333-333', 'Entertainment', 509.99, 'TV')

INSERT INTO Products (SKU, Description, Price, Name)
VALUES ('333-111-333', 'Mobile', 210.99, 'Samsung Glaxy')


INSERT INTO Products (SKU, Description, Price, Name)
VALUES ('444-000-111', 'Running equipment', 444.99, 'Cycling')


INSERT INTO Products (SKU, Description, Price, Name)
VALUES ('555-000-111', 'Children', 199.99, 'Video games')


INSERT INTO ProductCategories (ProductID, CategoryId)
VALUES (10, 14)

INSERT INTO ProductCategories (ProductID, CategoryId)
VALUES (11, 14)

INSERT INTO ProductCategories (ProductID, CategoryId)
VALUES (12, 15)

INSERT INTO ProductCategories (ProductID, CategoryId)
VALUES (13, 16)

INSERT INTO ProductCategories (ProductID, CategoryId)
VALUES (14, 16)

INSERT INTO ProductCategories (ProductID, CategoryId)
VALUES (15, 17)

INSERT INTO ProductCategories (ProductID, CategoryId)
VALUES (16, 18)




