﻿

CREATE Procedure spGetCategories

@CategoryId int

AS

SELECT * 
FROM Categories 
WHERE ID = @CategoryId

GO