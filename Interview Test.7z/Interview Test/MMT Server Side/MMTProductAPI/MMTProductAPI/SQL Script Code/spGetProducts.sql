﻿
CREATE Procedure spGetProducts

@ProductID int

AS

SELECT * 
FROM Products 
WHERE ID = @ProductID
GO


