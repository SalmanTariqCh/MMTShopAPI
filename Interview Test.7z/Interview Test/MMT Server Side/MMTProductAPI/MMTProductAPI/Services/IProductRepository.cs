﻿using MMTProductAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MMTProductAPI.Services
{
    public interface IProductRepository
    {
        ICollection<Product> GetProducts();           //To get the list of all products
        Product GetProduct(int productId);            //To get the product by productId
        Product GetProduct(string SKU);               //To get the product by SKU code
        bool ProductExist(int productId);             // To check whether the product exists

        bool CreateProduct(List<int> categoriesId, Product product);    //Create product which will be associated with category
        bool UpdateProduct(List<int> categoriesId, Product product);       //Update product which will be associated with category
        bool DeleteProduct(Product product);             //To delete product
        bool Save();

    }
}
