﻿using MMTProductAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MMTProductAPI.Services
{
    public class ProductRepository : IProductRepository
    {
        private ProductDbContext _productdbcontext;
        public ProductRepository(ProductDbContext productDbContext)
        {
            _productdbcontext = productDbContext;
        }
        public bool CreateProduct(List<int> categoriesId, Product product)
        {
            var categories = _productdbcontext.Categories.Where(c => categoriesId.Contains(c.Id)).ToList();

            foreach (var categgory in categories)
            {
                var productCategory = new ProductCategory()
                {
                    Category = categgory,
                    Product = product
                };
                _productdbcontext.Add(productCategory);
            }

            _productdbcontext.Add(product);       //As per code in the Create function, we are inserting records into 2 tables i.e.
            return Save();                       //ProductCategorgies and Product    

        }

        public bool DeleteProduct(Product product)
        {
            _productdbcontext.Remove(product);
            return Save();
        }

        public Product GetProduct(int productId)    //To get the product by productID
        {
            return _productdbcontext.Products.Where(p => p.Id == productId).FirstOrDefault();
        }

        public Product GetProduct(string SKU)   //To get the product by SKU codes
        {
            return _productdbcontext.Products.Where(ps => ps.SKU == SKU).FirstOrDefault();
        }

        public ICollection<Product> GetProducts()
        {
            return _productdbcontext.Products.OrderBy(p => p.Name).ToList();
        }

        public bool ProductExist(int productId)     //To check whether the product exist by productId
        {
            return _productdbcontext.Products.Any(p => p.Id == productId);
        }

        public bool Save()
        {
            var saved = _productdbcontext.SaveChanges();
            return saved>=0? true : false;
        }

        public bool UpdateProduct(List<int> categoriesId, Product product)
        {
            var categories = _productdbcontext.Categories.Where(c => categoriesId.Contains(c.Id)).ToList();

            /* We need to remove product records from ProductCategories before we update
            * the records in Product and ProductCategories  */

            var productcategoriestodelete = _productdbcontext.ProductCategories.Where(p => p.ProductId == product.Id);
            _productdbcontext.RemoveRange(productcategoriestodelete);

            foreach (var categgory in categories)
            {
                var productCategory = new ProductCategory()
                {
                    Category = categgory,
                    Product = product
                };
                _productdbcontext.Add(productCategory);
            }

            _productdbcontext.Update(product);  //We are updating records in 2 tables i.e Product and Product Categories
            return Save();


        }
    }
}
