﻿using MMTProductAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MMTProductAPI.Services
{
    public interface ICategoryRepository
    {
        ICollection<Category> GetCategories();                        // To get all the categories
        Category GetCategory(int categoryId);                         // To get category by categoryId
        ICollection<Category> GetAllCategoriesForAProduct(int productId);      // To get all categories for a specific Product
        ICollection<Product> GetAllProductsForCategory(int categoryId);     // To get all products for a specific category
        bool CategoryExist(int categoryId);
        bool IsDuplicateCategoryName(int categoryId, string categoryName);    //To check whether there is duplication of category name
        bool CreateCategory(Category category);                     //To create country and return true or fasle
        bool UpdateCategory(Category category);                     //To update country and return true or false
        bool DeleteCategory(Category category);                     //To Delete country and return true or false
        bool Save();
    }
}
