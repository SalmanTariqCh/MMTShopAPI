﻿using MMTProductAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MMTProductAPI.Services
{
    public class CategoryRepository : ICategoryRepository
    {
        private ProductDbContext _categorycontext; 
        public CategoryRepository(ProductDbContext categorycontext)
        {
            _categorycontext = categorycontext;
        }
        public bool CategoryExist(int categoryId)
        {
            return _categorycontext.Categories.Any(c => c.Id == categoryId);
        }

        public bool CreateCategory(Category category)
        {
            _categorycontext.Add(category);
            return Save();
        }

        public bool DeleteCategory(Category category)
        {
            _categorycontext.Remove(category);
            return Save();
        }

        public ICollection<Category> GetAllCategoriesForAProduct(int productId) //To get all the categories for a specific product
        {
            return _categorycontext.ProductCategories.Where(pc => pc.ProductId == productId).Select(c => c.Category).ToList();
        }

        public ICollection<Product> GetAllProductsForCategory(int categoryId)   //To get all the products of a specific category
        {
            return _categorycontext.ProductCategories.Where(pc => pc.CategoryId == categoryId).Select(p => p.Product).ToList();
        }

        public ICollection<Category> GetCategories()    //Get All the categories
        {
            return _categorycontext.Categories.OrderBy(c => c.Name).ToList();
        }

        public Category GetCategory(int categoryId)     //Get specific category by categoryId
        {
            return _categorycontext.Categories.Where(c => c.Id == categoryId).FirstOrDefault();
        }

        public bool IsDuplicateCategoryName(int categoryId, string categoryName)
        {
            //To check categoryName exist for a different categoryId
            var category = _categorycontext.Categories.Where(c => c.Name.Trim().ToUpper() == categoryName.Trim().ToUpper() && c.Id != categoryId).FirstOrDefault();

            return category == null ? false : true;
        }

        public bool Save()
        {
            var saved = _categorycontext.SaveChanges();

            return saved >= 0 ? true : false;
        }

        public bool UpdateCategory(Category category)
        {
            _categorycontext.Update(category);
            return Save();
        }
    }
}
