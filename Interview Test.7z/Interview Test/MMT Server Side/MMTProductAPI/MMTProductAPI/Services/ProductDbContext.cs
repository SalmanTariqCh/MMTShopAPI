﻿using Microsoft.EntityFrameworkCore;
using MMTProductAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MMTProductAPI.Services
{
    public class ProductDbContext : DbContext
    {
        public ProductDbContext(DbContextOptions<ProductDbContext> options)
            : base(options)
        {
            Database.Migrate();
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<ProductCategory> ProductCategories { get; set; }

        /* Product can belong to one category as per requirement but following code can be  
         used to make many to many relationships between Product and Categories*/

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //For ProductCategory
            modelBuilder.Entity<ProductCategory>()
                .HasKey(pc => new { pc.ProductId, pc.CategoryId });

            modelBuilder.Entity<ProductCategory>()         // Many to many relationships
                .HasOne(p => p.Product)
                .WithMany(pc => pc.ProductCategories)
                .HasForeignKey(p => p.ProductId);

            modelBuilder.Entity<ProductCategory>()         // Many to many relationships
               .HasOne(c => c.Category)
               .WithMany(pc => pc.ProductCategories)
               .HasForeignKey(c => c.CategoryId);

        }
    }
}
