﻿

API is built in .Net Core and many to many relationships between Products and Categories is used. This is done because table (product) can belong to Home (category) and Garden (category). This would also be helpful in future enhancements. If you wish to have one to one relationship, please let me know and I will make necessary changes. 

The name of the database is MMTShopAPIdb. I created this database in my local server. Please change the connection string (productDbConnectionString) in appsettings.json file as per your system in case if you wish to create database via entity framework migration. The Package Manager Console 
commands are following.

I.		enable-migrations
II.		add-migration InitialModel 
III.	update-database

Please delete the migration folder before you run the above commands.

Alternatively, please Restore the backup from \Interview Test\MMT Server Side\SQL Backup

I have also included SQL Insert statements in "SQL Script Code" folder. Please make that foreign keys are passed correctly to ProductCategories table. Insert statements will be used only if database is created via package manager console.

Extra functions are created which are not as part of the test but this would be used as per my understanding and possible enhancements. The details will be found in classes in Services folder.

There is also couple of bits missing as I could not get enough time to look into them.

Two small stored procedures are created in “SQL script Code” folder. They were not used anywhere in code as there was no need of it. Please let me know if you wish to use them rather LINQ and I will make necessary changes.
I did run the API in Postman and this is running fine.
Ideally, I would like to use Angular as user interface for future upgradation. 

Please let me know if you have any query. 

 

