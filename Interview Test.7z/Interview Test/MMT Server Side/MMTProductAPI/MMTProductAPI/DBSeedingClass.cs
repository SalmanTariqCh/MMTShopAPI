﻿using MMTProductAPI.Models;
using MMTProductAPI.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MMTProductAPI
{
    public static class DBSeedingClass
    {
        public static void SeedDataContext(this ProductDbContext context)
        {

            //    var category = new List<Category>()
            //    {
            //        new Category()
            //        {
            //            Name = "Home"
            //        }
            //    };

            //    context.Categories.AddRange(category);
            //    context.SaveChanges();

            var productcategories = new List<ProductCategory>()
            {
                new ProductCategory()
                {
                    Product = new Product()
                    {
                        Name = "Furniture",
                        SKU = "1111-1111-1111",
                        Description = "Home Furniture",
                        Price = 120,
                        ProductCategories = new List<ProductCategory>()
                        {
                            new ProductCategory { Category = new Category() { Name = "Home"}}
                        }
                    }
                }
            };

            context.ProductCategories.AddRange(productcategories);
            context.SaveChanges();

        }
    }
}
