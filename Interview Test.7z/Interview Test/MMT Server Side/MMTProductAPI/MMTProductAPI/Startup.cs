using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using MMTProductAPI.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MMTProductAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddMvc()  //To add MVC Services
                .AddNewtonsoftJson(o => o.SerializerSettings.ReferenceLoopHandling =       //To add Newtonsoft Json (v3.10)
                                    Newtonsoft.Json.ReferenceLoopHandling.Ignore);         //To ignore the ReferenceLoopHandling 

            var connectionstring = Configuration["connectionStrings:productDbConnectionString"];
            services.AddDbContext<ProductDbContext>(c => c.UseSqlServer(connectionstring));

            services.AddScoped<ICategoryRepository, CategoryRepository>();             //For registering the api/categories
            services.AddScoped<IProductRepository, ProductRepository>();             //For registering the api/products

            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "MMTProductAPI", Version = "v1" });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ProductDbContext context)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            //context.SeedDataContext();     //This should run only one time to populate the records into tables

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                name: "default",
                pattern: "{controller}/{action}/{id?}"
                );
            });
        }
    }
}
