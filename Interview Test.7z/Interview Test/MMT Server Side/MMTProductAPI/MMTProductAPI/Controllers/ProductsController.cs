﻿using Microsoft.AspNetCore.Mvc;
using MMTProductAPI.Dtos;
using MMTProductAPI.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MMTProductAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : Controller
    {
        private IProductRepository _productrepsitory;
        private ICategoryRepository _categoryRepository;
        public ProductsController(IProductRepository productRepository, ICategoryRepository categoryRepository)
        {
            _productrepsitory = productRepository;
            _categoryRepository = categoryRepository;
        }

        //api/products
        [HttpGet]
        [ProducesResponseType(200, Type = typeof(IEnumerable<ProductDto>))]
        [ProducesResponseType(400)]
        public IActionResult GetProducts()
        {
            var products = _productrepsitory.GetProducts();

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var productDto = new List<ProductDto>();
            foreach (var product in products)
            {
                productDto.Add(new ProductDto
                {
                    Id = product.Id,
                    SKU = product.SKU,
                    Description = product.Description,
                    Price = product.Price,
                    Name = product.Name
                });
            }

            return Ok(productDto);
        }


        //api/products/productId
        [HttpGet("{productId}", Name = "GetProduct")]
        [ProducesResponseType(200, Type = typeof(ProductDto))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult GetProduct(int productId)
        {
            if (!_productrepsitory.ProductExist(productId))
            {
                return NotFound();
            }

            var product = _productrepsitory.GetProduct(productId);
            
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var productDto = new ProductDto()
            {
                Id = product.Id,
                SKU = product.SKU,
                Description = product.Description,
                Price = product.Price,
                Name = product.Name
            };

            return Ok(productDto);
        }


    }
}
